numbers:
	seq 7 > $@
